# Evercrafted — Prompt Engineer
## Developer Spec v1.0

---

## 1. What This App Does

Prompt Engineer is an AI-powered tool that transforms a user's basic image description into a scored, production-ready prompt for Midjourney V7 and FLUX 1.1 Pro. It applies a 7-dimension scoring framework (Subject, Lighting, Color, Mood, Composition, Material, Spatial) to evaluate every generated prompt before the user sends it to an image model — catching weak dimensions and surfacing targeted fixes before a single pixel is rendered.

Target user: floral artists, wreath designers, and creative professionals building visual product assets who want high-quality AI image output without deep prompt-engineering knowledge.

---

## 2. User Flow

1. User lands on `/app/prompt-engineer` (must be authenticated)
2. System reads their tier from `profiles` table
3. User types an image description in the textarea
4. User selects aspect ratio + primary style + optional mood tags
5. User clicks **Generate & Score**
6. Client calls `POST /api/claude` with auth token
7. Server verifies auth + tier (minimum: Craft)
8. Server calls Anthropic API with Prompt Engineer system prompt
9. Claude returns JSON: `{ prompt, scores, gaps, reasoning }`
10. Client renders the enhanced prompt + 7-dimension score grid
11. Gaps below threshold (≤2) are flagged in red; remediation notes shown
12. User copies prompt OR regenerates a variation
13. Studio+ users can save to history
14. Atelier users can track iterations across multiple generations

---

## 3. Tier Feature Matrix

| Feature | Bloom | Craft | Studio | Atelier |
|---|:---:|:---:|:---:|:---:|
| Browse built-in style presets | ✅ | ✅ | ✅ | ✅ |
| Generate prompt (AI) | ❌ | ✅ | ✅ | ✅ |
| 7-dimension pre-score | ❌ | ✅ | ✅ | ✅ |
| Regenerate variation | ❌ | ✅ | ✅ | ✅ |
| Save prompt to history | ❌ | ❌ | ✅ | ✅ |
| View prompt history | ❌ | ❌ | ✅ | ✅ |
| Apply style presets | ❌ | ❌ | ✅ | ✅ |
| Batch generation (3+ prompts) | ❌ | ❌ | ❌ | ✅ |
| Iteration tracker + log | ❌ | ❌ | ❌ | ✅ |
| Create custom presets | ❌ | ❌ | ❌ | ✅ |

Locked features are always **visible with a blur overlay and upgrade CTA** — never hidden.

---

## 4. AI Integration Details

### Required Tier
Minimum: **Craft**

### System Prompt
```
You are an expert Midjourney V7 + FLUX 1.1 Pro prompt engineer. Transform basic image descriptions into scored, production-ready prompts.

Return ONLY valid JSON:
{
  "prompt": "40-75 word enhanced prompt — no MJ parameters",
  "scores": { "subject": 1-5, "lighting": 1-5, "color": 1-5, "mood": 1-5, "composition": 1-5, "material": 1-5, "spatial": 1-5 },
  "gaps": ["dimension: what was weak and how you fixed it"],
  "reasoning": "one sentence primary transformation"
}

RULES:
- Front-load the subject
- Specify lighting direction (not generic)
- Name a color treatment or film stock
- Include framing/composition technique
- 40-75 words — no exceptions
- No MJ parameters in prompt text
[+ contextual: style, AR, moods injected per request]
```

### Input Format
```typescript
{
  userInput: string,       // raw image description
  style: string,           // e.g. "editorial", "cinematic"
  aspectRatio: string,     // e.g. "16:9"
  moods: string[],         // e.g. ["Dramatic", "Warm"]
}
```

### Output Format
```typescript
{
  prompt: string,          // 40-75 word enhanced prompt
  scores: {
    subject: number,       // 1-5
    lighting: number,
    color: number,
    mood: number,
    composition: number,
    material: number,
    spatial: number,
  },
  gaps: string[],          // e.g. ["Lighting: no direction specified — added rim lighting from camera left"]
  reasoning: string,       // one sentence
}
```

### Token Budget
Max output: 1500 tokens. Typical response: 300–500 tokens.

---

## 5. Data Model

### `profiles`
| Column | Type | Notes |
|---|---|---|
| id | uuid | PK, references auth.users |
| email | text | |
| tier | text | bloom / craft / studio / atelier |
| stripe_customer_id | text | nullable |
| stripe_subscription_id | text | nullable |
| created_at | timestamptz | |
| updated_at | timestamptz | |

### `prompt_history`
| Column | Type | Notes |
|---|---|---|
| id | uuid | PK |
| user_id | uuid | FK → profiles |
| input_text | text | user's original description |
| output_prompt | text | enhanced prompt |
| style | text | |
| aspect_ratio | text | |
| moods | text[] | |
| scores | jsonb | all 7 dimension scores |
| avg_score | numeric(3,1) | computed client-side |
| created_at | timestamptz | |

### `style_presets`
| Column | Type | Notes |
|---|---|---|
| id | uuid | PK |
| user_id | uuid | nullable (null = system preset) |
| name | text | |
| style | text | |
| aspect_ratio | text | |
| moods | text[] | |
| description | text | |
| is_system | boolean | true = built-in, false = user-created |

### `prompt_generations` (usage log)
| Column | Type | Notes |
|---|---|---|
| id | uuid | PK |
| user_id | uuid | FK → profiles |
| skill | text | "prompt-engineer" |
| tokens_used | int | |
| created_at | timestamptz | |

### `iteration_logs` (Atelier only)
| Column | Type | Notes |
|---|---|---|
| id | uuid | PK |
| user_id | uuid | FK → profiles |
| session_name | text | user-defined |
| iterations | jsonb[] | array of iteration objects |
| created_at | timestamptz | |

### RLS Summary
- All tables: users see only their own rows
- `style_presets`: users see system presets + their own
- Service role key bypasses RLS (server-side only)

---

## 6. API Routes

| Route | Method | Auth Required | Tier | Description |
|---|---|---|---|---|
| `/api/claude` | POST | Yes (Bearer token) | Craft+ | Proxies request to Anthropic after tier check |
| `/api/history` | GET | Yes | Studio+ | Fetch user's prompt history |
| `/api/history` | POST | Yes | Studio+ | Save prompt to history |
| `/api/presets` | GET | Yes | Studio+ | Fetch system + user presets |
| `/api/presets` | POST | Yes | Atelier | Create custom preset |
| `/api/stripe/webhook` | POST | Stripe sig | — | Update tier on subscription change |
| `/api/stripe/checkout` | POST | Yes | — | Create Stripe checkout session |

---

## 7. Component Map

```
app/
  app/prompt-engineer/
    page.tsx                   ← main app shell, tab routing
    components/
      GenerateTab.tsx          ← input form + output display
      ScoreGrid.tsx            ← 7-dimension score visualization
      PromptOutput.tsx         ← enhanced prompt display + copy
      FluxParams.tsx           ← FLUX API parameter display
      HistoryTab.tsx           ← saved prompts list (Studio+)
      PresetsTab.tsx           ← style preset grid
      IterationTracker.tsx     ← iteration log UI (Atelier)
  components/
    ui/
      TierGate.tsx             ← blur overlay + upgrade CTA
      TierBadge.tsx            ← bloom/craft/studio/atelier badge
      AppHeader.tsx            ← Evercrafted wordmark + app name
      BotanicalDivider.tsx     ← ✦ divider with SVG leaf
```

---

## 8. Deployment Checklist

### Supabase
- [ ] Create project at supabase.com
- [ ] Run `supabase/migrations/001_init.sql`
- [ ] Enable Email auth (or OAuth)
- [ ] Copy `NEXT_PUBLIC_SUPABASE_URL` and keys to `.env.local`
- [ ] Verify RLS policies in Supabase Dashboard → Authentication → Policies
- [ ] Seed system style presets: `INSERT INTO style_presets (name, style, ..., is_system) VALUES ...`

### Stripe
- [ ] Create products + prices for all 4 tiers in Stripe Dashboard
- [ ] Copy price IDs to `.env.local`
- [ ] Set up webhook endpoint: `POST /api/stripe/webhook`
- [ ] Add webhook event: `customer.subscription.updated`
- [ ] Copy `STRIPE_WEBHOOK_SECRET` to `.env.local`
- [ ] Test upgrade flow: Bloom → Craft → verify tier updates in `profiles`

### Anthropic
- [ ] Create API key at console.anthropic.com
- [ ] Add to `.env.local` as `ANTHROPIC_API_KEY` (server-side only — never `NEXT_PUBLIC_`)
- [ ] Test `POST /api/claude` with valid auth token
- [ ] Confirm 403 response for Bloom-tier users

### Vercel
- [ ] `vercel --prod` from project root
- [ ] Add all env vars in Vercel Dashboard → Settings → Environment Variables
- [ ] Confirm `ANTHROPIC_API_KEY` is NOT marked as browser-accessible
- [ ] Set `NEXT_PUBLIC_APP_URL` to production domain

### Post-Deploy Tests
- [ ] Sign up as new user → confirm profile created with `bloom` tier
- [ ] Upgrade to Craft → confirm Generate button unlocks
- [ ] Generate a prompt → confirm score grid renders
- [ ] Upgrade to Studio → confirm history save works
- [ ] Upgrade to Atelier → confirm iteration tracker unlocks
- [ ] Downgrade → confirm locked features re-engage

---

## 9. Known Limitations & Future Work

**Known Limitations**
- Iteration Tracker (Atelier) stores iterations as `jsonb[]` — no cross-session analytics yet
- Style codes (V7 `--sref`) are referenced in skill docs but not surfaced in the UI
- No image upload for reference-based prompting (`--cref`) — future feature
- Usage limits per tier not enforced (track only, no hard cap)
- Mobile layout collapses score grid to 4 columns — 7-column grid is desktop-only

**Future Work**
- Image upload → `--cref` / `--sref` reference prompt generation
- Batch generation UI with comparison view (Atelier)
- Prompt library with public sharing
- Direct Replicate API integration (submit prompt → receive image in-app)
- Score trend chart across iteration history
- AI-powered gap auto-repair (regenerate only the weak dimension)
- Team workspaces (multi-user shared presets)
