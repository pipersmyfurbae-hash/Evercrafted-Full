-- supabase/migrations/001_init.sql
-- Evercrafted Prompt Engineer — initial schema

-- ── Profiles table ──────────────────────────────────────────
create table if not exists public.profiles (
  id           uuid primary key references auth.users(id) on delete cascade,
  email        text,
  tier         text not null default 'bloom'
                check (tier in ('bloom','craft','studio','atelier')),
  stripe_customer_id text,
  stripe_subscription_id text,
  created_at   timestamptz default now(),
  updated_at   timestamptz default now()
);

-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, email)
  values (new.id, new.email);
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ── Prompt history ───────────────────────────────────────────
create table if not exists public.prompt_history (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references public.profiles(id) on delete cascade,
  input_text   text not null,
  output_prompt text not null,
  style        text,
  aspect_ratio text,
  moods        text[],
  scores       jsonb,       -- { subject, lighting, color, mood, composition, material, spatial }
  avg_score    numeric(3,1),
  created_at   timestamptz default now()
);

create index prompt_history_user_id_idx on public.prompt_history(user_id);
create index prompt_history_created_at_idx on public.prompt_history(created_at desc);

-- ── Style presets (studio+) ──────────────────────────────────
create table if not exists public.style_presets (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid references public.profiles(id) on delete cascade,
  name         text not null,
  style        text,
  aspect_ratio text,
  moods        text[],
  description  text,
  is_system    boolean default false,  -- true = built-in Evercrafted presets
  created_at   timestamptz default now()
);

-- ── Usage tracking ────────────────────────────────────────────
create table if not exists public.prompt_generations (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid references public.profiles(id) on delete cascade,
  skill        text,
  tokens_used  int default 0,
  created_at   timestamptz default now()
);

-- ── Iteration log (atelier) ───────────────────────────────────
create table if not exists public.iteration_logs (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references public.profiles(id) on delete cascade,
  session_name text,
  iterations   jsonb[],    -- array of { prompt, scores, observations, action }
  created_at   timestamptz default now(),
  updated_at   timestamptz default now()
);

-- ── RLS policies ─────────────────────────────────────────────
alter table public.profiles enable row level security;
alter table public.prompt_history enable row level security;
alter table public.style_presets enable row level security;
alter table public.prompt_generations enable row level security;
alter table public.iteration_logs enable row level security;

-- profiles: users see only their own
create policy "users_own_profile" on public.profiles
  for all using (auth.uid() = id);

-- prompt_history: users see only their own
create policy "users_own_history" on public.prompt_history
  for all using (auth.uid() = user_id);

-- style_presets: users see system presets + their own
create policy "users_see_system_presets" on public.style_presets
  for select using (is_system = true or auth.uid() = user_id);
create policy "users_manage_own_presets" on public.style_presets
  for insert with check (auth.uid() = user_id);
create policy "users_delete_own_presets" on public.style_presets
  for delete using (auth.uid() = user_id);

-- usage: users see only their own
create policy "users_own_usage" on public.prompt_generations
  for all using (auth.uid() = user_id);

-- iterations: users see only their own
create policy "users_own_iterations" on public.iteration_logs
  for all using (auth.uid() = user_id);
