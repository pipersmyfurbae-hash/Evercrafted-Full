// app/api/claude/route.ts
// Server-side Claude proxy — verifies Supabase auth + tier before calling Anthropic API
// NEVER expose ANTHROPIC_API_KEY client-side

import { createClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'

const TIER_RANK: Record<string, number> = { bloom: 1, craft: 2, studio: 3, atelier: 4 }

const REQUIRED_TIER = 'craft' // minimum tier to call Claude at all

export async function POST(req: NextRequest) {
  // 1. Parse body
  const { messages, systemPrompt, maxTokens = 1500, skill } = await req.json()

  if (!messages || !systemPrompt) {
    return NextResponse.json({ error: 'Missing messages or systemPrompt' }, { status: 400 })
  }

  // 2. Verify auth via Supabase
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )

  const authHeader = req.headers.get('authorization')
  if (!authHeader) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { data: { user }, error: authError } = await supabase.auth.getUser(
    authHeader.replace('Bearer ', '')
  )

  if (authError || !user) {
    return NextResponse.json({ error: 'Invalid token' }, { status: 401 })
  }

  // 3. Check tier from profiles table
  const { data: profile } = await supabase
    .from('profiles')
    .select('tier')
    .eq('id', user.id)
    .single()

  const userTier = profile?.tier || 'bloom'

  if (TIER_RANK[userTier] < TIER_RANK[REQUIRED_TIER]) {
    return NextResponse.json({
      error: `This feature requires ${REQUIRED_TIER} tier or above`,
      requiredTier: REQUIRED_TIER,
      userTier,
    }, { status: 403 })
  }

  // 4. Call Anthropic API
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY!,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: maxTokens,
      system: systemPrompt,
      messages,
    }),
  })

  if (!response.ok) {
    const err = await response.json()
    return NextResponse.json({ error: err.error?.message || 'Claude API error' }, { status: 502 })
  }

  const data = await response.json()

  // 5. Optionally log usage to Supabase
  await supabase.from('prompt_generations').insert({
    user_id: user.id,
    skill,
    tokens_used: data.usage?.output_tokens || 0,
    created_at: new Date().toISOString(),
  }).catch(() => {}) // non-blocking

  return NextResponse.json(data)
}
